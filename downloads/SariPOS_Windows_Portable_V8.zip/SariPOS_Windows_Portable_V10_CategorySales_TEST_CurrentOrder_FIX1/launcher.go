package main

import (
    "crypto/hmac"
    "crypto/sha256"
    "encoding/base32"
    "encoding/base64"
    "encoding/binary"
    "encoding/json"
    "fmt"
    "io"
    "net"
    "net/http"
    "os"
    "os/exec"
    "os/user"
    "path/filepath"
    "regexp"
    "runtime"
    "strings"
)

const testSecret = "SariPOS-TEST-V2-2026-Compact-License-Key"

// The previous portable build used port 0, which means a new random port on every launch.
// Browser localStorage is scoped by origin, including the port, so that caused POS data
// to appear to reset after closing and reopening the app. This build uses a deterministic
// per-PC port so the same origin is reused every launch.
func appPort() int {
    sum := sha256.Sum256([]byte(deviceID()))
    n := int(binary.BigEndian.Uint16(sum[:2]))
    return 38000 + (n % 1000)
}

func normalize(s string) string {
    var b strings.Builder
    for _, r := range strings.ToUpper(strings.TrimSpace(s)) {
        if (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') { b.WriteRune(r) }
    }
    return b.String()
}

func deviceID() string {
    seed := machineGUID()
    sum := sha256.Sum256([]byte(seed))
    return fmt.Sprintf("SP-%X", sum[:])[:23]
}

func machineGUID() string {
    if runtime.GOOS != "windows" {
        host, _ := os.Hostname(); usr := ""
        if u, err := user.Current(); err == nil { usr = u.Username }
        return host + "|" + usr
    }
    queries := [][]string{
        {`HKLM\\SOFTWARE\\Microsoft\\Cryptography`, "/v", "MachineGuid"},
        {`HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Cryptography`, "/v", "MachineGuid"},
    }
    re := regexp.MustCompile(`(?i)MachineGuid\s+REG_SZ\s+([^\r\n]+)`)
    for _, q := range queries {
        out, err := exec.Command("reg.exe", append([]string{"query"}, q...)...).Output()
        if err == nil {
            if m := re.FindStringSubmatch(string(out)); len(m) == 2 { return strings.TrimSpace(m[1]) }
        }
    }
    host, _ := os.Hostname(); usr := ""
    if u, err := user.Current(); err == nil { usr = u.Username }
    return host + "|" + usr
}

func expectedLicense(code string) bool {
    clean := normalize(code)
    if len(clean) != 16 { return false }
    mac := hmac.New(sha256.New, []byte(testSecret))
    _, _ = mac.Write([]byte("SariPOS-V2|" + deviceID()))
    encoded := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(mac.Sum(nil))
    expected := encoded[:16]
    return hmac.Equal([]byte(clean), []byte(expected))
}

func verifyHandler(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    if r.Method != http.MethodPost { io.WriteString(w, `{"valid":false,"code":"INVALID_METHOD"}`); return }
    var body struct{ Code string `json:"code"` }
    if err := json.NewDecoder(r.Body).Decode(&body); err != nil { io.WriteString(w, `{"valid":false,"code":"INVALID_REQUEST"}`); return }
    clean := normalize(body.Code)
    if clean == "" { io.WriteString(w, `{"valid":false,"code":"EMPTY_LICENSE"}`); return }
    if len(clean) != 16 { io.WriteString(w, `{"valid":false,"code":"INVALID_FORMAT"}`); return }
    if expectedLicense(clean) { io.WriteString(w, `{"valid":true,"code":"LICENSE_VALID"}`) } else { io.WriteString(w, `{"valid":false,"code":"INVALID_LICENSE"}`) }
}

type accountState struct {
    SetupDone    bool   `json:"setupDone"`
    AdminPassword string `json:"adminPassword"`
}

func readAccountState(path string) accountState {
    var st accountState
    data, err := os.ReadFile(path)
    if err != nil { return st }
    _ = json.Unmarshal(data, &st)
    return st
}

func writeAccountState(path string, st accountState) error {
    data, err := json.MarshalIndent(st, "", "  ")
    if err != nil { return err }
    tmp := path + ".tmp"
    if err := os.WriteFile(tmp, data, 0644); err != nil { return err }
    _ = os.Remove(path)
    return os.Rename(tmp, path)
}

func accountStateHandler(statePath string) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Content-Type", "application/json")
        if r.Method == http.MethodGet {
            _ = json.NewEncoder(w).Encode(readAccountState(statePath))
            return
        }
        if r.Method != http.MethodPost { http.Error(w, `{"ok":false}`, http.StatusMethodNotAllowed); return }
        var st accountState
        if err := json.NewDecoder(r.Body).Decode(&st); err != nil { http.Error(w, `{"ok":false}`, http.StatusBadRequest); return }
        if strings.TrimSpace(st.AdminPassword) == "" { http.Error(w, `{"ok":false}`, http.StatusBadRequest); return }
        if err := writeAccountState(statePath, st); err != nil { http.Error(w, `{"ok":false}`, http.StatusInternalServerError); return }
        io.WriteString(w, `{"ok":true}`)
    }
}

func saveFileHandler(w http.ResponseWriter, r *http.Request, fallbackDir string) {
    w.Header().Set("Content-Type", "application/json")
    if r.Method != http.MethodPost { http.Error(w, `{"success":false,"message":"Invalid method"}`, http.StatusMethodNotAllowed); return }
    var body struct {
        Filename string `json:"filename"`
        Base64   string `json:"base64"`
    }
    if err := json.NewDecoder(r.Body).Decode(&body); err != nil { http.Error(w, `{"success":false,"message":"Invalid request"}`, http.StatusBadRequest); return }
    name := filepath.Base(strings.TrimSpace(body.Filename))
    if name == "" || name == "." { http.Error(w, `{"success":false,"message":"Invalid filename"}`, http.StatusBadRequest); return }
    data, err := base64.StdEncoding.DecodeString(body.Base64)
    if err != nil { http.Error(w, `{"success":false,"message":"Invalid base64"}`, http.StatusBadRequest); return }
    targetDir := fallbackDir
    if home, err := os.UserHomeDir(); err == nil && home != "" {
        d := filepath.Join(home, "Downloads")
        if err := os.MkdirAll(d, 0755); err == nil { targetDir = d }
    }
    if err := os.MkdirAll(targetDir, 0755); err != nil { http.Error(w, `{"success":false,"message":"Could not create Downloads folder"}`, http.StatusInternalServerError); return }
    target := filepath.Join(targetDir, name)
    if err := os.WriteFile(target, data, 0644); err != nil { http.Error(w, `{"success":false,"message":"Could not save file"}`, http.StatusInternalServerError); return }
    resp := map[string]any{"success": true, "path": target, "message": "Saved to Downloads"}
    _ = json.NewEncoder(w).Encode(resp)
}

func indexHandler(w http.ResponseWriter, r *http.Request, indexPath, statePath string) {
    html, err := os.ReadFile(indexPath)
    if err != nil { http.Error(w, "SariPOS index unavailable", http.StatusInternalServerError); return }
    st := readAccountState(statePath)
    stateJSON, _ := json.Marshal(st)
    script := fmt.Sprintf(`<script>
window.SariPOSPCState=%s;
window.SariPOSNative={
 getDeviceId:function(){return %q;},
 verifyCompactLicense:function(code){
  try{var xhr=new XMLHttpRequest();xhr.open('POST','/api/verify',false);xhr.setRequestHeader('Content-Type','application/json');xhr.send(JSON.stringify({code:String(code||'')}));return xhr.responseText||JSON.stringify({valid:false,code:'VERIFY_ERROR'});}catch(e){return JSON.stringify({valid:false,code:'VERIFY_ERROR'});}
 },
 saveAccountState:function(json){
  try{var xhr=new XMLHttpRequest();xhr.open('POST','/api/account-state',false);xhr.setRequestHeader('Content-Type','application/json');xhr.send(String(json||'{}'));return xhr.status===200?'OK':'ERROR';}catch(e){return 'ERROR';}
 },
 saveFileBase64:function(filename,base64,mime){
  try{var xhr=new XMLHttpRequest();xhr.open('POST','/api/save-file',false);xhr.setRequestHeader('Content-Type','application/json');xhr.send(JSON.stringify({filename:String(filename||''),base64:String(base64||''),mime:String(mime||'application/octet-stream')}));return xhr.responseText||JSON.stringify({success:false,message:'Save failed'});}catch(e){return JSON.stringify({success:false,message:'Save failed'});}
 }
};
</script>`, stateJSON, deviceID())
    content := strings.Replace(string(html), "</head>", script+"</head>", 1)
    w.Header().Set("Content-Type", "text/html; charset=utf-8")
    _, _ = io.WriteString(w, content)
}

func pathExists(p string) bool { _, err := os.Stat(p); return err == nil }

func findBrowser() (string, bool) {
    candidates := []string{
        os.Getenv("PROGRAMFILES") + `\\Microsoft\\Edge\\Application\\msedge.exe`,
        os.Getenv("PROGRAMW6432") + `\\Microsoft\\Edge\\Application\\msedge.exe`,
        os.Getenv("PROGRAMFILES(X86)") + `\\Microsoft\\Edge\\Application\\msedge.exe`,
        os.Getenv("LOCALAPPDATA") + `\\Microsoft\\Edge\\Application\\msedge.exe`,
        os.Getenv("PROGRAMFILES") + `\\Google\\Chrome\\Application\\chrome.exe`,
        os.Getenv("PROGRAMW6432") + `\\Google\\Chrome\\Application\\chrome.exe`,
        os.Getenv("PROGRAMFILES(X86)") + `\\Google\\Chrome\\Application\\chrome.exe`,
        os.Getenv("LOCALAPPDATA") + `\\Google\\Chrome\\Application\\chrome.exe`,
    }
    for _, p := range candidates { if p != "" && pathExists(p) { return p, true } }
    for _, name := range []string{"msedge.exe", "chrome.exe"} { if p, err := exec.LookPath(name); err == nil { return p, true } }
    return "", false
}

func openURLFallback(url string) bool {
    cmd := exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url)
    return cmd.Start() == nil
}

func main() {
    if runtime.GOOS != "windows" { return }
    exePath, err := os.Executable(); if err != nil { return }
    root := filepath.Dir(exePath)
    indexPath := filepath.Join(root, "app", "index.html")
    assetsDir := filepath.Join(root, "assets")
    if !pathExists(indexPath) || !pathExists(assetsDir) { return }

    dataDir := filepath.Join(root, "SariPOS_Data")
    _ = os.MkdirAll(dataDir, 0755)
    statePath := filepath.Join(dataDir, "account_state.json")
    browserProfile := filepath.Join(dataDir, "BrowserProfile")
    _ = os.MkdirAll(browserProfile, 0755)
    fallbackDownloads := filepath.Join(dataDir, "Downloads")

    port := appPort()
    listenAddr := fmt.Sprintf("127.0.0.1:%d", port)
    ln, err := net.Listen("tcp", listenAddr)
    if err != nil {
        msg := fmt.Sprintf("SariPOS could not start because local port %d is unavailable. Close other SariPOS instances and try again.", port)
        _ = os.WriteFile(filepath.Join(root, "SariPOS_START_ERROR.txt"), []byte(msg), 0644)
        return
    }

    mux := http.NewServeMux()
    mux.HandleFunc("/api/verify", verifyHandler)
    mux.HandleFunc("/api/account-state", accountStateHandler(statePath))
    mux.HandleFunc("/api/save-file", func(w http.ResponseWriter, r *http.Request) { saveFileHandler(w, r, fallbackDownloads) })
    mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        if r.URL.Path == "/index.html" || r.URL.Path == "/" { indexHandler(w, r, indexPath, statePath); return }
        rel := strings.TrimPrefix(filepath.Clean(r.URL.Path), string(filepath.Separator))
        if strings.HasPrefix(rel, "..") { http.NotFound(w, r); return }
        file := filepath.Join(root, filepath.FromSlash(rel))
        info, err := os.Stat(file); if err != nil || info.IsDir() { http.NotFound(w, r); return }
        http.ServeFile(w, r, file)
    })

    server := &http.Server{Handler: mux}
    go func(){ _ = server.Serve(ln) }()
    url := fmt.Sprintf("http://127.0.0.1:%d/index.html", port)

    browser, ok := findBrowser()
    if ok {
        args := []string{
            "--app=" + url,
            "--user-data-dir=" + browserProfile,
            "--no-first-run", "--no-default-browser-check", "--start-maximized",
        }
        cmd := exec.Command(browser, args...)
        cmd.Dir = root
        if err := cmd.Start(); err == nil {
            _ = cmd.Wait()
            _ = server.Close()
            return
        }
    }

    if openURLFallback(url) { return }
    _ = os.WriteFile(filepath.Join(root, "SariPOS_START_ERROR.txt"), []byte("SariPOS could not start a browser. Please install Microsoft Edge or Google Chrome, then run SariPOS.exe again."), 0644)
    _ = server.Close()
}
