module saripos-windows

go 1.22
