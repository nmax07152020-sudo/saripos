SariPOS Windows Portable V10 — Category Sales TEST — Current Order Fix 1
=======================================================================

FIX:
- Restored Current Order quantity controls (+ / −).
- Restored direct quantity editing in the Current Order input.
- Restored cart-only refresh so quantity changes immediately update totals,
  payment/change fields, and the cart without resetting the whole POS page.

PRESERVED:
- Windows V10 deterministic localhost persistence behavior.
- Inventory, Transactions, Reports, Total Sales by Category.
- Existing login/session, Device ID, 7-day trial, compact license behavior.
- Existing Windows portable launcher and Downloads export behavior.

TEST:
1. Open SariPOS.exe.
2. Go to POS.
3. Add a product to Current Order.
4. Test + until the product stock limit.
5. Test − back to 1, then remove it at 0.
6. Type a quantity directly in the quantity box.
7. Confirm subtotal, total, payment/change fields update.
8. Complete a test sale and verify Transactions/Reports.

IMPORTANT:
This is a separate TEST build. The original V10 test folder is untouched.
Do not deploy or replace a locked baseline until testing is complete.
