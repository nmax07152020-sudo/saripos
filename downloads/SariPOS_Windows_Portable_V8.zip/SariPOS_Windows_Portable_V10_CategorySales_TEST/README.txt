SariPOS Windows Portable V9 - Data Persistence TEST
====================================================

FIX:
- Uses a deterministic per-PC localhost port instead of port 0/random ports.
- This preserves the same browser origin between launches, so localStorage POS data (inventory, sales, products, users, settings) persists after closing/reopening SariPOS.
- Keeps the V8 login/password flow, Device ID, compact license, 7-day trial, category sales, logo, and exports.
- Keeps native account_state.json persistence.
- Keeps native save-to-Downloads for JSON/XLSX exports.

TEST:
1. Extract this folder.
2. Open SariPOS.exe.
3. Add/edit inventory and complete a sale.
4. Close SariPOS.exe completely.
5. Open SariPOS.exe again.
6. Verify inventory, sales, transactions and reports are still present.

IMPORTANT:
This is a TEST build. Do not replace the locked Windows V8 baseline yet.
