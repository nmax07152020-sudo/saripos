SariPOS Windows Portable V8 TEST
================================

Fix included:
- First-time automatic admin sign-in.
- One-time password setup is persisted in SariPOS_Data/account_state.json.
- Closing/reopening SariPOS will NOT show the password setup again after it has been completed.
- Admin password is retained across fresh app launches.
- Normal session persistence remains available through the browser profile.
- Uses the shared SariPOS License Generator V3.
- Uses the SariPOS launcher logo in the login and navigation areas.

Test flow:
1. First open: automatic admin sign-in -> Create Your Admin Password.
2. Save the new password.
3. Close SariPOS.exe.
4. Open SariPOS.exe again.
5. The password setup must NOT appear again.
6. If you logged out before closing, normal login is expected; the one-time setup must still remain completed.
